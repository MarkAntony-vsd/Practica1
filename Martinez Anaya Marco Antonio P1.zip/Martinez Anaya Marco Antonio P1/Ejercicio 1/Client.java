import java.io.*;
import java.net.*;

public class Client {

    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            mostrarUso();
            System.exit(1);
        }

        String nombreHost = args[0];
        int numeroPuerto = Integer.parseInt(args[1]);

        iniciarCliente(nombreHost, numeroPuerto);
    }

    // Método para mostrar cómo usar el programa desde la consola
    private static void mostrarUso() {
        System.err.println("Uso desde consola: java Client <nombre de host> <numero puerto>");
    }

    // Método para iniciar la conexión del cliente
    private static void iniciarCliente(String nombreHost, int numeroPuerto) {
        try (
            Socket socketEco = new Socket(nombreHost, numeroPuerto);
            PrintWriter escritor = new PrintWriter(socketEco.getOutputStream(), true);
            BufferedReader lector = new BufferedReader(new InputStreamReader(socketEco.getInputStream()));
            BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in))
        ) {
            procesarComunicacion(escritor, lector, teclado);

            socketEco.close();
        } catch (UnknownHostException e) {
            manejarErrorHostDesconocido(nombreHost);
        } catch (IOException e) {
            manejarErrorIO(nombreHost);
        }
    }

    // Método para procesar la comunicación entre el cliente y el servidor
    private static void procesarComunicacion(PrintWriter escritor, BufferedReader lector, BufferedReader teclado) throws IOException {
        String usuarioEscribio;
        String recibidoDeServer;
        int number = 1;

        while (number != 0) {
            usuarioEscribio = leerEntradaUsuario(teclado);
            number = Integer.parseInt(usuarioEscribio);
            enviarMensaje(escritor, usuarioEscribio);

            if (number != 0) {
                recibidoDeServer = recibirMensaje(lector);
                mostrarMensajeRecibido(recibidoDeServer);
            }
        }
    }

    // Método para leer la entrada del usuario desde el teclado
    private static String leerEntradaUsuario(BufferedReader teclado) throws IOException {
        return teclado.readLine();
    }

    // Método para enviar un mensaje al servidor
    private static void enviarMensaje(PrintWriter escritor, String mensaje) {
        escritor.println(mensaje);
    }

    // Método para recibir un mensaje del servidor
    private static String recibirMensaje(BufferedReader lector) throws IOException {
        return lector.readLine();
    }

    // Método para mostrar el mensaje recibido del servidor
    private static void mostrarMensajeRecibido(String mensaje) {
        System.out.println("Número recibido: " + mensaje);
    }

    // Método para manejar el error cuando el host no es conocido
    private static void manejarErrorHostDesconocido(String nombreHost) {
        System.err.println("No se conoce al host " + nombreHost);
        System.exit(1);
    }

    // Método para manejar errores de entrada/salida
    private static void manejarErrorIO(String nombreHost) {
        System.err.println("No se pudo obtener E/S para la conexión con " + nombreHost);
        System.exit(1);
    }
}
