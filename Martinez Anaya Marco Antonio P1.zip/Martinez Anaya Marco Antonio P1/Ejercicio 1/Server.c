#include <stdio.h>
#include <string.h>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

// Prototipos de funciones
int inicializar_winsock(WSADATA *wsa);
SOCKET crear_socket();
int asociar_socket(SOCKET server_socket, struct sockaddr_in *server);
SOCKET esperar_cliente(SOCKET server_socket, struct sockaddr_in *client, int *client_len);
int procesar_cliente(SOCKET client_socket);
void limpiar_recursos(SOCKET server_socket, SOCKET client_socket);

// Función principal
int main() {
    WSADATA wsa;
    SOCKET server_socket, client_socket;
    struct sockaddr_in server, client;
    int client_len;

    if (inicializar_winsock(&wsa) != 0) {
        return 1;
    }

    server_socket = crear_socket();
    if (server_socket == INVALID_SOCKET) {
        return 1;
    }

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(12500);

    if (asociar_socket(server_socket, &server) != 0) {
        return 1;
    }

    printf("Esperando al cliente...\n");
    client_socket = esperar_cliente(server_socket, &client, &client_len);
    if (client_socket == INVALID_SOCKET) {
        return 1;
    }

    printf("Conexión aceptada.\n");
    if (procesar_cliente(client_socket) != 0) {
        limpiar_recursos(server_socket, client_socket);
        return 1;
    }

    limpiar_recursos(server_socket, client_socket);
    system("pause");

    return 0;
}

// Función para inicializar Winsock
int inicializar_winsock(WSADATA *wsa) {
    printf("Inicializando Winsock...\n");
    if (WSAStartup(MAKEWORD(2, 2), wsa) != 0) {
        printf("Error al inicializar Winsock. Código: %d\n", WSAGetLastError());
        return 1;
    }
    printf("Winsock inicializado.\n");
    return 0;
}

// Función para crear el socket del servidor
SOCKET crear_socket() {
    SOCKET server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == INVALID_SOCKET) {
        printf("No se pudo crear el socket: %d\n", WSAGetLastError());
        WSACleanup();
    } else {
        printf("Socket creado.\n");
    }
    return server_socket;
}

// Función para asociar el socket
int asociar_socket(SOCKET server_socket, struct sockaddr_in *server) {
    if (bind(server_socket, (struct sockaddr *)server, sizeof(*server)) == SOCKET_ERROR) {
        printf("Error al asociar el socket: %d\n", WSAGetLastError());
        closesocket(server_socket);
        WSACleanup();
        return 1;
    }
    printf("Socket asociado.\n");
    listen(server_socket, 3);
    return 0;
}

// Función para esperar una conexión de un cliente
SOCKET esperar_cliente(SOCKET server_socket, struct sockaddr_in *client, int *client_len) {
    *client_len = sizeof(struct sockaddr_in);
    SOCKET client_socket = accept(server_socket, (struct sockaddr *)client, client_len);
    if (client_socket == INVALID_SOCKET) {
        printf("Error al aceptar conexión: %d\n", WSAGetLastError());
    }
    return client_socket;
}

// Función para procesar los mensajes del cliente
int procesar_cliente(SOCKET client_socket) {
    char client_message[2000];
    int recv_size, number;
    char str[12];

    do {
        recv_size = recv(client_socket, client_message, 2000, 0);
        if (recv_size == SOCKET_ERROR) {
            printf("Error al recibir datos.\n");
            return 1;
        }

        client_message[recv_size] = '\0';
        number = atoi(client_message);
        printf("Número recibido: %i\n", number);

        if (number != 0) {
            number++;
            const char *response = strcat(itoa(number, str, 10), "\n");
            send(client_socket, response, strlen(response), 0);
        }

    } while (number != 0);

    return 0;
}

// Función para liberar recursos
void limpiar_recursos(SOCKET server_socket, SOCKET client_socket) {
    closesocket(client_socket);
    closesocket(server_socket);
    WSACleanup();
    printf("Recursos liberados.\n");
}