import java.net.*; // Paquete para clases de red
import java.io.*;  // Paquete para clases de entrada/salida

public class Server {

    public static void main(String[] args) throws IOException {
        
        if (args.length != 1) {
            mostrarUso();
            System.exit(1);
        }

        int numeroPuerto = Integer.parseInt(args[0]);
        iniciarServidor(numeroPuerto);
    }

    // Método para mostrar el uso correcto del programa
    private static void mostrarUso() {
        System.err.println("Uso desde consola: <numero puerto>");
    }

    // Método para iniciar el servidor
    private static void iniciarServidor(int numeroPuerto) {
        try (
            ServerSocket socketdelServidor = new ServerSocket(numeroPuerto); // Escuchando peticiones
            Socket socketdelCliente = socketdelServidor.accept(); // Acepta la conexión del cliente
            PrintWriter escritor = new PrintWriter(socketdelCliente.getOutputStream(), true);
            BufferedReader lector = new BufferedReader(new InputStreamReader(socketdelCliente.getInputStream()))
        ) {
            procesarComunicacion(lector, escritor);
            cerrarConexiones(socketdelServidor, socketdelCliente);
        } catch (IOException e) {
            manejarErrorServidor(numeroPuerto, e);
        }
    }

    // Método para procesar la comunicación con el cliente
    private static void procesarComunicacion(BufferedReader lector, PrintWriter escritor) throws IOException {
        // Lee el mensaje del cliente
        String clientMessage = lector.readLine();
        System.out.println("Mensaje recibido del cliente: " + clientMessage);

        // Envía la respuesta al cliente
        String respuesta = clientMessage + " como estas.";
        escritor.println(respuesta);
        System.out.println("Respuesta enviada al cliente.");
    }

    // Método para cerrar las conexiones del servidor y cliente
    private static void cerrarConexiones(ServerSocket socketdelServidor, Socket socketdelCliente) throws IOException {
        socketdelServidor.close();
        socketdelCliente.close();
        System.out.println("Conexiones cerradas.");
    }

    // Método para manejar los errores del servidor
    private static void manejarErrorServidor(int numeroPuerto, IOException e) {
        System.out.println("Ocurrió una excepción al intentar escuchar en el puerto " + numeroPuerto 
                           + " o esperando una conexión.");
        System.out.println(e.getMessage());
    }
}
