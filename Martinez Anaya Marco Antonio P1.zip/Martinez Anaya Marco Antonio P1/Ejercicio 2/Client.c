#include <stdio.h>
#include <stdlib.h>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

// Prototipos de funciones
int inicializar_winsock();
SOCKET crear_socket();
int conectar_al_servidor(SOCKET sock, char *ip, int puerto);
int enviar_mensaje(SOCKET sock, char *mensaje);
int recibir_respuesta(SOCKET sock);
void limpiar_recursos(SOCKET sock);

// Función principal
int main(int argc, char *argv[]) {
    WSADATA wsa;
    SOCKET sock;
    char *ip = "192.168.56.1";
    int puerto = 12500;

    if (inicializar_winsock(&wsa) != 0) {
        return 1;
    }

    sock = crear_socket();
    if (sock == INVALID_SOCKET) {
        return 1;
    }

    if (conectar_al_servidor(sock, ip, puerto) < 0) {
        limpiar_recursos(sock);
        return 1;
    }

    if (enviar_mensaje(sock, "Hola\n") < 0) {
        limpiar_recursos(sock);
        return 1;
    }

    if (recibir_respuesta(sock) < 0) {
        limpiar_recursos(sock);
        return 1;
    }

    limpiar_recursos(sock);

    system("pause");
    return 0;
}

// Función para inicializar Winsock
int inicializar_winsock(WSADATA *wsa) {
    if (WSAStartup(MAKEWORD(2, 2), wsa) != 0) {
        printf("Error: No se pudo inicializar Winsock. Código de error: %d\n", WSAGetLastError());
        return 1;
    }
    printf("Winsock inicializado.\n");
    return 0;
}

// Función para crear un socket
SOCKET crear_socket() {
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) {
        printf("Error: No se pudo crear el socket. Código de error: %d\n", WSAGetLastError());
        WSACleanup();
    } else {
        printf("Socket creado.\n");
    }
    return sock;
}

// Función para conectar al servidor
int conectar_al_servidor(SOCKET sock, char *ip, int puerto) {
    struct sockaddr_in server;
    server.sin_addr.s_addr = inet_addr(ip);
    server.sin_family = AF_INET;
    server.sin_port = htons(puerto);

    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        printf("Error: No se pudo conectar al servidor. Código de error: %d\n", WSAGetLastError());
        return -1;
    }
    printf("Conectado al servidor.\n");
    return 0;
}

// Función para enviar un mensaje
int enviar_mensaje(SOCKET sock, char *mensaje) {
    if (send(sock, mensaje, strlen(mensaje), 0) < 0) {
        printf("Error: No se pudo enviar el mensaje.\n");
        return -1;
    }
    printf("Mensaje enviado.\n");
    return 0;
}

// Función para recibir la respuesta del servidor
int recibir_respuesta(SOCKET sock) {
    char server_reply[2000];
    int recv_size = recv(sock, server_reply, sizeof(server_reply), 0);
    if (recv_size == SOCKET_ERROR) {
        printf("Error: No se pudo recibir la respuesta.\n");
        return -1;
    }
    server_reply[recv_size] = '\0';
    printf("Respuesta recibida: %s\n", server_reply);
    return 0;
}

// Función para limpiar recursos
void limpiar_recursos(SOCKET sock) {
    closesocket(sock);
    WSACleanup();
    printf("Recursos liberados.\n");
}